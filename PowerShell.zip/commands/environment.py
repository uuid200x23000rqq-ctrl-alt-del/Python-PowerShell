import os


def get_variable(name):
    return os.environ.get(name)


def set_variable(name, value):
    os.environ[name] = value


def list_variables():
    return os.environ.items()
