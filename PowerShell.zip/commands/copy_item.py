import shutil


def run(args):

    if len(args) < 2:
        print("Copy-Item : Missing required arguments.")
        return

    source = args[0]
    destination = args[1]

    try:
        shutil.copy2(source, destination)

    except FileNotFoundError:
        print(
            f"Copy-Item : Cannot find path '{source}' "
            "because it does not exist."
        )

    except PermissionError:
        print(
            "Copy-Item : Access to the path is denied."
        )

    except Exception as error:
        print(
            f"Copy-Item : {error}"
        )
