import os


def run(args):

    if len(args) == 0:
        return

    path = " ".join(args)

    try:
        os.chdir(path)

    except FileNotFoundError:
        print(
            f"Set-Location : Cannot find path '{path}' "
            "because it does not exist."
        )

    except NotADirectoryError:
        print(
            f"Set-Location : The path '{path}' is not a directory."
        )
