from art import text2art

print(text2art("PowerShell"))
input("h")
