import os


def run(args):

    if len(args) < 2:
        print("Rename-Item : Missing old or new name.")
        return

    old_name = args[0]
    new_name = args[1]

    try:
        os.rename(old_name, new_name)

    except FileNotFoundError:
        print(
            f"Rename-Item : Cannot find path '{old_name}' "
            "because it does not exist."
        )

    except Exception as error:
        print(f"Rename-Item : {error}")
