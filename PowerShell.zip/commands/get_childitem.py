import os


def run(args):

    # Environment provider
    if len(args) > 0 and args[0].lower() == "env:":
        print()
        print("Name                           Value")
        print("----                           -----")

        for name, value in os.environ.items():
            print(f"{name:<30} {value}")

        print()
        return


    # Normal filesystem provider
    path = os.getcwd()

    if len(args) > 0:
        path = args[0]

    items = os.listdir(path)

    for item in items:
        full_path = os.path.join(path, item)

        if os.path.isdir(full_path):
            print(f"<DIR>          {item}")
        else:
            size = os.path.getsize(full_path)
            print(f"{size:>10} {item}")
