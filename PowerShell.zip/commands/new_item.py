import os


def run(args):

    if len(args) == 0:
        print("New-Item : Missing path argument.")
        return

    path = args[0]

    item_type = "file"

    if "-ItemType" in args:
        index = args.index("-ItemType")

        if index + 1 < len(args):
            item_type = args[index + 1].lower()


    try:

        if item_type == "directory":
            os.mkdir(path)

        else:
            with open(path, "w"):
                pass


    except FileExistsError:
        print(
            f"New-Item : The item '{path}' already exists."
        )
