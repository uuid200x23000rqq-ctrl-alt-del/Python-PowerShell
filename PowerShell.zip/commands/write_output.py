def run(args):

    # No arguments
    if len(args) == 0:
        print()
        return

    # Output everything
    print(" ".join(args))
