import os


def run(args):

    if len(args) == 0:
        print("Test-Path : Missing path argument.")
        return

    path = " ".join(args)

    print(os.path.exists(path))
