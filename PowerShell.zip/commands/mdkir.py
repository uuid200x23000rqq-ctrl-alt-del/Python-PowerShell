import os


def run(args):

    if len(args) == 0:
        print("mkdir : Missing directory name.")
        return

    path = " ".join(args)

    try:
        os.makedirs(path)

    except FileExistsError:
        print(
            f"mkdir : Cannot create directory '{path}' "
            "because it already exists."
        )

    except Exception as error:
        print(f"mkdir : {error}")
