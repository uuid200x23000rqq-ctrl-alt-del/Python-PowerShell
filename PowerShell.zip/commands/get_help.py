HELP = {
    "Write-Output": "Sends output to the pipeline.",
    "Get-Location": "Gets the current working location.",
    "Set-Location": "Changes the current working location.",
    "Get-ChildItem": "Lists files and directories.",
    "Get-Content": "Displays the contents of a file.",
    "New-Item": "Creates a new file or directory.",
    "Remove-Item": "Deletes a file or directory.",
    "Clear-Host": "Clears the console screen.",
    "Exit": "Closes Python PowerShell.",
    "Get-Help": "Displays help about PowerShell commands."
}


def run(args):

    if not args:

        print("Python PowerShell Help")
        print()
        print("Available commands:")
        print()

        for command in sorted(HELP):
            print(f"  {command}")

        print()
        print("Type 'Get-Help <command>' for more information.")
        return

    command = args[0].lower()

    for name, description in HELP.items():
        if name.lower() == command:
            print(name)
            print("-" * len(name))
            print(description)
            return

    print(f"Get-Help : No help found for '{args[0]}'.")
