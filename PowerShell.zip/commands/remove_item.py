import os


def run(args):

    if len(args) == 0:
        print("Remove-Item : Missing path argument.")
        return

    path = " ".join(args)

    try:

        if os.path.isdir(path):
            os.rmdir(path)

        else:
            os.remove(path)


    except FileNotFoundError:
        print(
            f"Remove-Item : Cannot find path '{path}' "
            "because it does not exist."
        )


    except OSError:
        print(
            f"Remove-Item : Cannot remove '{path}'. "
            "The directory may not be empty."
        )
