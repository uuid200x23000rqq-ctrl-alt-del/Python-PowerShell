import os
import datetime


def run(args):

    if len(args) == 0:
        print("Get-Item : Missing path argument.")
        return

    path = " ".join(args)

    if not os.path.exists(path):
        print(
            f"Get-Item : Cannot find path '{path}' "
            "because it does not exist."
        )
        return


    name = os.path.basename(path)

    print()
    print(f"Name          : {name}")

    if os.path.isdir(path):
        print("Type          : Directory")
    else:
        print("Type          : File")
        print(f"Length        : {os.path.getsize(path)} bytes")

    created = datetime.datetime.fromtimestamp(
        os.path.getctime(path)
    )

    modified = datetime.datetime.fromtimestamp(
        os.path.getmtime(path)
    )

    print(f"Created       : {created}")
    print(f"Last Modified : {modified}")
    print()
