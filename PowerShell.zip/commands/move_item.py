import shutil


def run(args):

    if len(args) < 2:
        print("Move-Item : Missing source or destination.")
        return

    source = args[0]
    destination = args[1]

    try:
        shutil.move(source, destination)

    except FileNotFoundError:
        print(
            f"Move-Item : Cannot find path '{source}' "
            "because it does not exist."
        )

    except Exception as error:
        print(f"Move-Item : {error}")
