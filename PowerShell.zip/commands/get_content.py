def run(args):

    if len(args) == 0:
        print("Get-Content : Missing path argument.")
        return

    filename = " ".join(args)

    try:
        with open(filename, "r") as file:
            print(file.read(), end="")

    except FileNotFoundError:
        print(
            f"Get-Content : Cannot find path '{filename}' "
            "because it does not exist."
        )
