VERSION = "1.1.4"
COPYRIGHT = "Suhan & Windows Backyard Software Corporation"
