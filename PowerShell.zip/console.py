import os
import sys
import ctypes

from version import VERSION, COPYRIGHT


def is_admin():
    """Return True if running as administrator."""
    return ctypes.windll.shell32.IsUserAnAdmin()


def initialize():
    """Initialize the console."""

    # Classic PowerShell colors
    os.system("color 17")

    # Window title
    if is_admin():
        os.system("title Administrator: Python PowerShell")
    else:
        os.system("title Python PowerShell")


def startup_banner():
    """Display the startup banner."""

    print("Python PowerShell")
    print(f"Version {VERSION}")

    print(r"""
 ____          _    _                        ____                                ____   _            _  _
|  _ \  _   _ | |_ | |__    ___   _ __      |  _ \   ___  __      __  ___  _ __ / ___| | |__    ___ | || |
| |_) || | | || __|| '_ \  / _ \ | '_ \     | |_) | / _ \ \ \ /\ / / / _ \| '__|\___ \ | '_ \  / _ \| || |
|  __/ | |_| || |_ | | | || (_) || | | |    |  __/ | (_) | \ V  V / |  __/| |    ___) || | | ||  __/| || |
|_|     \__, | \__||_| |_| \___/ |_| |_|    |_|     \___/   \_/\_/   \___||_|   |____/ |_| |_| \___||_||_|
        |___/
    """)
    print()

    print(
        f"Built on Python "
        f"{sys.version_info.major}."
        f"{sys.version_info.minor}."
        f"{sys.version_info.micro}"
    )

    print()

    print(f"Copyright (C) {COPYRIGHT}.")
    print()
    print("Try the new cross-platform Python PowerShell which would come out after this")
    print()

