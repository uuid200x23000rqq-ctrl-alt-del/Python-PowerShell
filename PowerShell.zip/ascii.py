from art import text2art

print(text2art("Python PowerShell"))

input("h")
