import console

from shell import Shell


console.initialize()
console.startup_banner()

shell = Shell()
shell.run()
