import os
import subprocess
import shlex

from prompt import build
from commands import write_output
from commands import get_location
from commands import set_location
from commands import get_childitem
from commands import clear_host
from commands import new_item
from commands import remove_item
from commands import get_content
from commands import get_help
from commands import copy_item
from commands import test_path
from commands import get_item
from commands import move_item
from commands import rename_item
from commands import mdkir
from commands import environment

class Shell:

    def __init__(self):
        self.running = True


    def run(self):

        while self.running:

            command = input(build())

            if command == "":
                continue

            if command.lower().startswith("$env:"):

                data = command[5:]

                if "=" in data:
                    name, value = data.split("=", 1)

                    value = value.strip('"')

                    environment.set_variable(name, value)

                else:
                    value = environment.get_variable(data)

                    if value is not None:
                        print(value)

                continue

            parts = shlex.split(command, posix=False)

            cmd = parts[0].lower()
            args = parts[1:]


            if cmd == "exit":
                self.running = False
                continue


            elif cmd in ("write-output", "echo"):
                write_output.run(args)

            elif cmd in ("get-location", "pwd"):
                print()
                print("Path")
                print("----")
                get_location.run(args)
                print()

            elif cmd in ("set-location", "cd"):
                set_location.run(args)

            elif cmd in ("get-childitem", "get-child-item", "dir", "ls"):
                get_childitem.run(args)

            elif cmd in ("clear-host", "cls", "clear"):
                clear_host.run(args)

            elif cmd in ("get-content", "type", "cat", "gc"):
                get_content.run(args)

            elif cmd in ("new-item", "ni"):
                new_item.run(args)

            elif cmd in ("remove-item", "rm", "del", "rmdir"):
                remove_item.run(args)

            elif cmd in ("get-help", "help"):
                get_help.run(args)

            elif cmd in ("copy-item", "copy", "cp", "cpi"):
                copy_item.run(args)

            elif cmd == "test-path":
                test_path.run(args)

            elif cmd in ("get-item", "gi"):
                get_item.run(args)

            elif cmd in ("move-item", "move", "mv"):
                move_item.run(args)

            elif cmd in ("rename-item", "ren", "rni"):
                rename_item.run(args)

            elif cmd in ("mdkir", "md"):
                mdkir.run(args)

            else:
                try:
                    subprocess.Popen([cmd] + args)
                except FileNotFoundError:
                    print(
                        f"{cmd} : The term '{cmd}' is not recognized as "
                        "the name of a cmdlet, function, script file, or "
                        "operable program."
                    )
                    print()
