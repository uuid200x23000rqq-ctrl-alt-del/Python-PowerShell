import os
from console import is_admin

USERNAME = os.getlogin()
os.chdir(rf"C:\Users\{USERNAME}")

def build():

    current_path = os.getcwd()

    if is_admin():
        os.chdir(rf"C:\Windows\system32")
        current_path = os.getcwd()
        return f"Administrator: PS {current_path}> "

    return f"PS {current_path}> "
